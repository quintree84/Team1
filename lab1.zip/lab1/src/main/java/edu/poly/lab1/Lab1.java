/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package edu.poly.lab1;

import Divide.Binhphuong;
import Divide.Calculator;

/**
 *
 * @author Bùi Tạ Hồng Đạt
 */
public class Lab1 {

    public static void main(String[] args) {
     new Calculator().setVisible(true);
      new Binhphuong().setVisible(true);
    }
}
